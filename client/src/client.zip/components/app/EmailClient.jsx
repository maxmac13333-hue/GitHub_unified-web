import { Mail, Inbox, Send, Trash, Star, Search } from 'lucide-react';

export default function EmailClient() {
    const emails = [
        { id: 1, sender: "Job Offer", subject: "Freelance Project: Website Fix", time: "10:30 AM", preview: "Hi, We are looking for a developer to fix...", active: true },
        { id: 2, sender: "Server Alert", subject: "[CRITICAL] Server Down", time: "09:15 AM", preview: "System detected high latency in..." },
        { id: 3, sender: "Mom", subject: "Dinner tonight?", time: "Yesterday", preview: "Are you coming home for dinner?..." },
    ];

    return (
        <div className="flex h-full bg-white text-slate-800 font-sans">
            {/* Sidebar */}
            <div className="w-56 bg-slate-50 flex flex-col border-r border-slate-100 text-sm">
                <div className="p-5 flex items-center gap-3 font-black text-blue-600 text-xl tracking-tight">
                    <Mail size={24} /> Inbox
                </div>
                <div className="px-3 space-y-1.5 mt-2">
                    <div className="flex items-center gap-3 px-4 py-2.5 bg-blue-50 text-blue-700 rounded-xl cursor-pointer font-bold shadow-sm border border-blue-100">
                        <Inbox size={18} /> Inbox <span className="ml-auto bg-blue-600 text-white text-[10px] px-2 py-0.5 rounded-full shadow-sm">3</span>
                    </div>
                    <div className="flex items-center gap-3 px-4 py-2.5 text-slate-500 hover:bg-slate-100 hover:text-slate-800 rounded-xl cursor-pointer font-medium transition-colors">
                        <Send size={18} /> Sent
                    </div>
                    <div className="flex items-center gap-3 px-4 py-2.5 text-slate-500 hover:bg-slate-100 hover:text-slate-800 rounded-xl cursor-pointer font-medium transition-colors">
                        <Star size={18} /> Important
                    </div>
                    <div className="flex items-center gap-3 px-4 py-2.5 text-slate-500 hover:bg-red-50 hover:text-red-600 rounded-xl cursor-pointer font-medium transition-colors">
                        <Trash size={18} /> Trash
                    </div>
                </div>
            </div>

            {/* Email List */}
            <div className="w-80 border-r border-slate-100 flex flex-col bg-white">
                <div className="p-4 border-b border-slate-100 bg-white/50 backdrop-blur-sm z-10 relative">
                    <div className="relative">
                        <Search size={16} className="absolute left-3.5 top-3 text-slate-400" />
                        <input type="text" placeholder="Search mail" className="w-full bg-slate-50 border border-slate-200 rounded-full pl-10 pr-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500 max-w-full" />
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto">
                    {emails.map(email => (
                        <div key={email.id} className={`p-5 border-b border-slate-100 cursor-pointer transition-colors ${email.active ? 'bg-blue-50/50 border-l-4 border-l-blue-500' : 'hover:bg-slate-50 border-l-4 border-l-transparent'}`}>
                            <div className="flex justify-between items-baseline mb-1">
                                <span className={`text-sm ${email.active ? 'font-black text-slate-900' : 'font-bold text-slate-700'}`}>{email.sender}</span>
                                <span className={`text-[10px] font-bold ${email.active ? 'text-blue-600' : 'text-slate-400'}`}>{email.time}</span>
                            </div>
                            <div className={`text-sm mb-1.5 truncate ${email.active ? 'font-bold text-slate-800' : 'font-medium text-slate-600'}`}>{email.subject}</div>
                            <div className="text-xs text-slate-500 truncate">{email.preview}</div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Reading Pane */}
            <div className="flex-1 flex flex-col bg-slate-50/50">
                <div className="p-8 bg-white shadow-sm m-6 rounded-3xl flex-1 border border-slate-200">
                    <h2 className="text-2xl font-black mb-6 text-slate-800">Freelance Project: Website Fix</h2>
                    <div className="flex items-center gap-4 mb-8 border-b border-slate-100 pb-5">
                        <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-black text-lg shadow-sm border-2 border-white">J</div>
                        <div>
                            <div className="font-bold text-slate-800 text-lg">Job Offer</div>
                            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">To: Me</div>
                        </div>
                    </div>
                    <div className="text-slate-600 leading-relaxed space-y-4">
                        <p className="font-medium text-slate-800">Hi,</p>
                        <p>We are looking for a Python developer to fix our backend API. It seems to be crashing when under load.</p>
                        <p className="inline-block bg-green-50 text-green-700 px-3 py-1.5 rounded-lg border border-green-200 font-bold uppercase tracking-widest text-xs mt-2">Budget: 5,000 THB</p>
                        <p>Are you available?</p>
                        <div className="pt-8">
                            <button className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:shadow-lg hover:shadow-blue-500/30 transition-all active:scale-95 shadow-md">Reply to Email</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}