import React, { useState, useEffect, useRef } from "react";
import Editor from "@monaco-editor/react";
import { RotateCcw, Play, CheckCircle2, Terminal } from "lucide-react";
import { TheInfiniteGrid } from "../components/ui/the-infinite-grid";
export default function ChallengePage() {
  // --- State for Challenge ---
  const [code, setCode] = useState(`# Write your code from scratch here!
# Challenge: Calculate VAT
# Take price as input and print "Total price with VAT is [value]"
`);

  const [terminalLines, setTerminalLines] = useState([]);
  const [pyodide, setPyodide] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRunning, setIsRunning] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const [currentInput, setCurrentInput] = useState("");
  const [currentPrompt, setCurrentPrompt] = useState("");

  const inputResolverRef = useRef(null);
  const terminalRef = useRef(null);

  const testCases = [
    { input: "100", expected: "Total price with VAT is 107.0" },
    { input: "500", expected: "Total price with VAT is 535.0" },
    { input: "1500", expected: "Total price with VAT is 1605.0" }
  ];

  const normalizeText = (text) => {
    if (!text) return "";
    return text
      .trim()
      .replace(/\r/g, "")
      .replace(/(\d+\.\d{5,})/g, (match) => {
        return parseFloat(parseFloat(match).toFixed(2)).toString();
      })
      .replace(/\s+/g, " ");
  };

  // Auto Scroll Terminal
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [terminalLines]);

  const appendLine = (text) => {
    setTerminalLines((prev) => [...prev, text]);
  };

  /* =========================
      INIT PYODIDE
  ========================== */
  useEffect(() => {
    const initPyodide = async () => {
      setIsLoading(true);
      try {
        const instance = await window.loadPyodide();
        
        // Setup Output Stream
        instance.setStdout({
          batched: (text) => { if (text.trim()) appendLine(text); }
        });
        instance.setStderr({
          batched: (text) => appendLine("❌ Error: " + text)
        });

        const restoreBridge = `
import builtins
from js import requestInputFromJS
async def custom_input(prompt=""):
    return await requestInputFromJS(prompt)
builtins.input = custom_input
`;
        await instance.runPythonAsync(restoreBridge);
        
        setPyodide(instance);
        setIsLoading(false);
        appendLine("Python Ready 🐍");
      } catch (err) {
        appendLine("Failed to load Python: " + err.message);
      }
    };

    if (!window.loadPyodide) {
      const script = document.createElement("script");
      script.src = "https://cdn.jsdelivr.net/pyodide/v0.23.4/full/pyodide.js";
      script.onload = initPyodide;
      document.head.appendChild(script);
    } else {
      initPyodide();
    }

    // Global Bridge for JS -> Python input
    window.requestInputFromJS = (promptText) => {
      setCurrentPrompt(promptText);
      return new Promise((resolve) => {
        inputResolverRef.current = resolve;
      });
    };
  }, []);

  /* =========================
      RUN MODE (Interactive)
  ========================== */
  const handleRun = async () => {
    if (!pyodide || isRunning) return;
    setTerminalLines([]);
    setIsRunning(true);
    setIsSuccess(false);

    try {
      const processedCode = code.replace(/input\(/g, "await input(");
      
      const wrappedCode = `
import asyncio
import sys, builtins
from js import requestInputFromJS

# --- RESET STREAMS ---
sys.stdout = sys.__stdout__
sys.stdin = sys.__stdin__

async def custom_input(prompt=""):
    return await requestInputFromJS(prompt)
builtins.input = custom_input
# ---------------------

async def __user_code__():
${processedCode.split("\n").map(l => "    " + l).join("\n")}

await __user_code__()
`;
      await pyodide.runPythonAsync(wrappedCode);
    } catch (err) {
      appendLine("Error: " + err.message);
    } finally {
      setIsRunning(false);
    }
  };

  /* =========================
      SUBMIT MODE (Auto-Grading)
  ========================== */
  const handleSubmit = async () => {
    if (!pyodide || isRunning) return;
    setIsRunning(true);
    setTerminalLines(["--- Starting Auto-Grading ---"]);
    let allPassed = true;

    try {
      for (let i = 0; i < testCases.length; i++) {
        const test = testCases[i];
        const encodedCode = btoa(unescape(encodeURIComponent(code)));
        
        const gradingScript = `
import sys, builtins, base64
from io import StringIO

def sync_input(p=""): 
    return sys.stdin.readline().rstrip('\\n')

builtins.input = sync_input
sys.stdin = StringIO("${test.input}")
sys.stdout = StringIO()

try:
    exec(base64.b64decode("${encodedCode}").decode('utf-8'), {"input": sync_input, "__builtins__": builtins}, {})
    output = sys.stdout.getvalue()
except Exception as e: 
    output = str(e)

output.strip()
`;
        const rawResult = await pyodide.runPythonAsync(gradingScript);
        const actual = normalizeText(rawResult);
        const expected = normalizeText(test.expected);

        if (actual.includes(expected)) {
          appendLine(`✅ Test Case ${i + 1}: Passed`);
        } else {
          appendLine(`❌ Test Case ${i + 1}: Failed`);
          appendLine(`   Expected: "${expected}"`);
          appendLine(`   Got: "${actual}"`);
          allPassed = false;
          break; 
        }
      }
    } catch (err) {
      appendLine(`❌ System Error: ` + err.message);
      allPassed = false;
    } finally {
      await pyodide.runPythonAsync(`
import builtins
from js import requestInputFromJS
async def custom_input(prompt=""):
    return await requestInputFromJS(prompt)
builtins.input = custom_input
`);
      setIsRunning(false);
    }

    if (allPassed) {
      setIsSuccess(true);
      alert("🎉 ยอดเยี่ยม! ผ่านทุกกรณีทดสอบ");
    }
  };

  const handleInputKeyDown = (e) => {
    if (e.key === "Enter" && inputResolverRef.current) {
      appendLine(currentPrompt + currentInput);
      inputResolverRef.current(currentInput);
      inputResolverRef.current = null;
      setCurrentInput("");
      setCurrentPrompt("");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-transparent text-slate-800 font-sans relative">
      {/* Container simulating a floating glass window for the challenge */}
      <div className="flex-1 flex overflow-hidden p-6 gap-6 max-h-[calc(100vh-140px)] drop-shadow-sm">
        
        {/* Sidebar */}
        <aside className="w-1/3 bg-white/70 backdrop-blur-2xl border border-slate-200/60 rounded-[2rem] p-8 overflow-y-auto flex flex-col shadow-xl">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/30">
              1
            </div>
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-800 to-slate-600">
              ความท้าทาย: คำนวณ VAT
            </h1>
          </div>

          <p className="text-slate-600 mb-6 leading-relaxed font-medium">
            จงเขียนโปรแกรมรับค่าราคาสินค้าจากผู้ใช้งาน 
            แล้วคำนวณราคาสุทธิรวมภาษีมูลค่าเพิ่ม 7% 
            จากนั้นแสดงผลลัพธ์ในรูปแบบ <code className="bg-slate-100 px-1.5 py-0.5 rounded-md text-blue-600 font-mono text-sm border border-slate-200">Total price with VAT is [value]</code>
          </p>

          <div className="bg-slate-50/80 p-5 rounded-2xl border border-slate-200/60 font-mono text-sm mb-6 space-y-3 shadow-inner">
            <p className="text-slate-400 text-xs font-bold tracking-wider uppercase">// ตัวอย่างผลลัพธ์</p>
            <p className="text-slate-700">Input: 100</p>
            <p className="text-slate-700 font-semibold bg-white px-3 py-2 rounded-lg border border-slate-200">Output: Total price with VAT is 107.0</p>
          </div>

          <div className="text-xs text-slate-500 space-y-2 mt-auto bg-white/50 p-4 rounded-xl border border-slate-100">
            <p className="flex items-start gap-2"><span className="text-amber-500">💡</span> <span>หมายเหตุ: ระบบจะปัดเศษทศนิยมที่เกินให้โดยอัตโนมัติ</span></p>
            <p className="flex items-start gap-2"><span className="text-amber-500">💡</span> <span>ใช้ฟังก์ชัน <code className="text-blue-500 bg-blue-50 px-1 rounded">input()</code> และ <code className="text-blue-500 bg-blue-50 px-1 rounded">print()</code> ตามปกติ</span></p>
          </div>
        </aside>

        {/* Main Content (Editor & Terminal) */}
        <div className="flex-1 flex flex-col overflow-hidden bg-white/70 backdrop-blur-2xl border border-slate-200/60 rounded-[2rem] shadow-xl">
          {/* Header */}
          <header className="h-16 border-b border-slate-200/60 flex items-center justify-between px-6 shrink-0 bg-white/40">
            <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-blue-500" />
                <span className="font-bold text-slate-700">Code Editor</span>
            </div>
            {isLoading && <span className="text-blue-500 text-sm font-medium animate-pulse flex items-center gap-2"><span>Loading Python Engine</span><div className="w-4 h-4 rounded-full border-2 border-blue-500 border-t-transparent animate-spin"></div></span>}
          </header>

          {/* Code Editor */}
          <div className="flex-1 relative">
            <Editor 
              height="100%" 
              defaultLanguage="python" 
              theme="light" 
              value={code} 
              onChange={(v) => setCode(v || "")} 
              options={{ fontSize: 16, minimap: { enabled: false }, padding: { top: 24, bottom: 24 }, scrollBeyondLastLine: false, fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace" }} 
            />
          </div>

          {/* Terminal Section */}
          <div className="h-2/5 flex flex-col relative border-t border-slate-200/60 bg-slate-50/80">
            <div className="flex items-center gap-2 px-6 py-3 border-b border-slate-200 bg-white/50">
              <Terminal size={16} className="text-slate-500" />
              <span className="text-xs uppercase tracking-widest text-slate-500 font-bold">Terminal Output</span>
            </div>
            
            <div ref={terminalRef} className="flex-1 p-6 font-mono text-sm overflow-y-auto text-slate-700">
              {terminalLines.map((line, i) => (
                <div key={i} className={`mb-1.5 ${line.startsWith('✅') ? 'text-emerald-600 font-medium' : line.startsWith('❌') ? 'text-red-500 font-medium' : 'text-slate-600'}`}>
                  {line}
                </div>
              ))}
              
              {/* Input Prompt Overlay */}
              {inputResolverRef.current && (
                <div className="flex items-center text-blue-600 font-medium mt-2">
                  <span>{currentPrompt} &gt; </span>
                  <input 
                    autoFocus 
                    className="bg-transparent outline-none flex-1 text-slate-800 ml-2 border-b-2 border-blue-200 focus:border-blue-500 transition-colors" 
                    value={currentInput} 
                    onChange={(e) => setCurrentInput(e.target.value)} 
                    onKeyDown={handleInputKeyDown} 
                  />
                </div>
              )}
            </div>

            {/* Action Bar */}
            <div className="h-20 bg-white border-t border-slate-200/60 flex items-center justify-between px-6 shrink-0 rounded-b-[2rem]">
              <div className="flex space-x-3">
                <button 
                  onClick={handleRun} 
                  disabled={isRunning || isLoading} 
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 disabled:opacity-50 px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 transition-colors border border-slate-200 hover:border-slate-300"
                >
                  <Play size={16} className="text-slate-500"/> <span>Run Output</span>
                </button>
                <button 
                  onClick={() => setTerminalLines([])} 
                  className="bg-slate-50 hover:bg-red-50 text-slate-400 hover:text-red-500 border border-slate-200 hover:border-red-200 px-4 py-2.5 rounded-xl transition-colors"
                  title="Clear Terminal"
                >
                  <RotateCcw size={16}/>
                </button>
              </div>
              <button 
                onClick={handleSubmit} 
                disabled={isRunning || isLoading} 
                className={`px-8 py-3 rounded-xl font-bold transition-all shadow-md active:scale-95 text-white flex items-center gap-2 ${isSuccess ? 'bg-emerald-500 hover:bg-emerald-600 shadow-emerald-500/20' : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-blue-500/30'}`}
              >
                {isSuccess ? <><CheckCircle2 size={18}/> Passed!</> : "Submit Code"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
