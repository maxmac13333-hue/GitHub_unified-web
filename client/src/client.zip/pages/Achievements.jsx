import { useEffect, useState } from 'react';
import axios from 'axios';
import { Trophy, Star, ShieldAlert, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export default function Achievements() {
    const [list, setList] = useState([]);
    const [mounted, setMounted] = useState(false);
    const navigate = useNavigate();
    const { t } = useTranslation();
    const user = JSON.parse(localStorage.getItem('user'));

    useEffect(() => {
        setTimeout(() => setMounted(true), 100);
        if (user) axios.get(`http://localhost:3001/achievements/${user.id}`).then(r => setList(r.data)).catch(() => {});
    }, []);

    const getDifficultyStyle = (diff) => {
        switch (diff) {
            case 'Medium': return { color: 'border-green-200', bg: 'bg-green-50', text: 'text-green-600', icon: <Star size={20} className="text-green-500" fill="currentColor" /> };
            case 'Hard': return { color: 'border-orange-200', bg: 'bg-orange-50', text: 'text-orange-600', icon: <ShieldAlert size={20} className="text-orange-500" /> };
            case 'Very Hard': return { color: 'border-red-200', bg: 'bg-red-50', text: 'text-red-600', icon: <Trophy size={20} className="text-red-500" /> };
            default: return { color: 'border-blue-200', bg: 'bg-blue-50', text: 'text-blue-600', icon: <Star size={20} className="text-blue-500" /> };
        }
    };

    return (
        <div className="min-h-screen relative p-8 pb-32 transition-colors duration-300 overflow-y-auto">
            <button onClick={() => navigate('/menu')}
                className="fixed top-6 right-6 bg-white/80 p-3 rounded-full hover:bg-slate-100 hover:text-red-500 text-slate-400 border border-slate-200/60 shadow-lg transition-all z-50 backdrop-blur-md">
                <X size={20} />
            </button>

            <div className={`text-center mb-12 relative z-10 transition-all duration-700 pt-8 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'}`}>
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-amber-400 to-orange-500 rounded-[1.5rem] shadow-xl border-4 border-white mb-6 transform -rotate-6">
                 <Trophy className="w-10 h-10 text-white" />
              </div>
              <h1 className="text-4xl md:text-5xl font-black text-slate-800 tracking-tight">
                  <span className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 bg-clip-text text-transparent">{t('achievements.title', 'HALL OF FAME')}</span>
              </h1>
              <p className="mt-4 text-slate-500 font-medium">ดูประวัติความสำเร็จและรางวัลที่คุณปลดล็อกได้ที่นี่</p>
            </div>

            <div className="max-w-4xl mx-auto space-y-4 relative z-10">
                {list.map((ach, i) => {
                    const style = getDifficultyStyle(ach.difficulty);
                    const percent = parseFloat(ach.global_percent);
                    return (
                        <div key={ach.achievement_id}
                            className={`relative p-6 rounded-[1.5rem] bg-white/80 backdrop-blur-md border transition-all duration-500 group overflow-hidden
                                ${ach.is_unlocked ? 'opacity-100 shadow-md border-slate-200' : 'opacity-60 grayscale-[0.8] bg-slate-50/80 border-slate-100 shadow-sm'} 
                                ${ach.is_unlocked ? 'hover:border-blue-300 hover:shadow-xl hover:shadow-blue-500/10 hover:-translate-y-1' : ''}
                                ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
                            style={{ transitionDelay: `${200 + i * 60}ms` }}>
                            
                            {/* Decorative background glow for unlocked items */}
                            {ach.is_unlocked === 1 && (
                                <div className="absolute top-0 right-0 w-64 h-full bg-gradient-to-l from-amber-50 to-transparent pointer-events-none opacity-50 group-hover:opacity-100 transition-opacity"></div>
                            )}
                            
                            <div className="flex flex-col md:flex-row justify-between items-center gap-6 relative z-10">
                                <div className="flex items-center gap-5 flex-1 w-full">
                                    <div className={`p-4 rounded-[1.25rem] ${style.bg} border ${style.color} shadow-sm relative`}>
                                      {style.icon}
                                    </div>
                                    <div>
                                        <h3 className={`text-xl font-bold ${ach.is_unlocked ? 'text-slate-800' : 'text-slate-500'} group-hover:text-blue-600 transition-colors`}>{ach.name}</h3>
                                        <p className="text-sm text-slate-500 mt-1">{ach.description}</p>
                                        <span className={`text-[10px] uppercase tracking-wider font-bold px-3 py-1 rounded-full mt-3 inline-block ${style.bg} ${style.text} border ${style.color}`}>{ach.difficulty}</span>
                                    </div>
                                </div>
                                <div className="text-right min-w-[130px] border-t md:border-t-0 md:border-l border-slate-100 md:pl-6 pt-4 md:pt-0 w-full md:w-auto flex md:block justify-between items-center">
                                    {percent === 0 ? (
                                        <div className="text-sm text-slate-400 italic font-medium bg-slate-50 px-4 py-2 rounded-lg border border-slate-100">0.0%<br />{t('achievements.locked', 'LOCKED')}</div>
                                    ) : (
                                        <>
                                          <div className="text-3xl font-black text-slate-800">{percent.toFixed(1)}%</div>
                                          <div className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mt-1 bg-slate-50 inline-block px-2 py-0.5 rounded-md border border-slate-100">{t('achievements.progress', 'Completed')}</div>
                                        </>
                                    )}
                                </div>
                            </div>
                            {ach.is_unlocked === 1 && (
                                <div className="absolute top-4 right-4 px-3 py-1.5 rounded-full text-[10px] font-black bg-gradient-to-r from-amber-400 to-orange-400 text-white shadow-md animate-bounce-in flex items-center gap-1 border border-amber-300/50">
                                  <Star size={10} fill="currentColor" /> UNLOCKED!
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
}