import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Shuffle, PlusSquare, Users, Settings, User, LogOut, X, Volume2, Save } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function OnlineMenu() {
    const navigate = useNavigate();
    const { t } = useTranslation();
    const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')) || {});
    const [mounted, setMounted] = useState(false);
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [showSettingsModal, setShowSettingsModal] = useState(false);
    const [createData, setCreateData] = useState({ roomName: '', maxPlayers: 2, password: '' });
    const [settingData, setSettingData] = useState({ newName: user.username || '', volume: localStorage.getItem('musicVolume') || 50 });

    useEffect(() => { setTimeout(() => setMounted(true), 100); }, []);

    const handleCreateRoom = async (e) => {
        e.preventDefault();
        if (!createData.roomName) return alert(t('onlineMenu.settingsModal.errorNameEmpty'));
        try { const res = await axios.post('http://localhost:3001/rooms/create', { ...createData, hostId: user.id }); navigate(`/lobby/${res.data.roomId}`); } catch { alert(t('onlineMenu.settingsModal.errorCreateRoom')); }
    };

    const handleSaveSettings = async () => {
        try {
            if (settingData.newName !== user.username) {
                await axios.post('http://localhost:3001/user/update', { userId: user.id, newName: settingData.newName });
                const newUser = { ...user, username: settingData.newName };
                localStorage.setItem('user', JSON.stringify(newUser)); setUser(newUser);
            }
            alert(t('onlineMenu.settingsModal.successMessage')); setShowSettingsModal(false);
        } catch { alert(t('onlineMenu.settingsModal.errorMessage')); }
    };

    const menuItems = [
        { name: t('onlineMenu.quickJoin'), sub: "Quick Join", icon: <Shuffle size={28} />, color: "from-purple-500 to-purple-700", action: () => navigate('/matchmaking') },
        { name: t('onlineMenu.createRoom'), sub: "Create", icon: <PlusSquare size={28} />, color: "from-green-500 to-green-700", action: () => setShowCreateModal(true) },
        { name: t('onlineMenu.joinList'), sub: "Join List", icon: <Users size={28} />, color: "from-blue-500 to-blue-700", action: () => navigate('/join-room') },
        { name: t('onlineMenu.solo'), sub: "Solo", icon: <User size={28} />, color: "from-cat-orange to-cat-amber", action: () => navigate('/menu') },
        { name: t('onlineMenu.settings'), sub: "Settings", icon: <Settings size={28} />, color: "from-slate-500 to-slate-700", action: () => setShowSettingsModal(true) },
        { name: t('onlineMenu.back'), sub: "Back", icon: <LogOut size={28} />, color: "from-red-500 to-red-700", action: () => navigate('/menu') },
    ];

    return (
        <div className="min-h-screen relative transition-colors duration-300 overflow-y-auto bg-slate-50">
            <div className="fixed inset-0 bg-white/40 pointer-events-none"></div>

            <div className="relative z-10 flex flex-col items-center min-h-screen p-8">
            <div className="z-10 w-full max-w-5xl">
                <h1 className={`text-5xl md:text-6xl font-black text-center mb-16 tracking-tight transition-all duration-1000 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-8'}`}>
                    <span className="bg-gradient-to-r from-blue-600 via-indigo-500 to-purple-600 bg-clip-text text-transparent">{t('onlineMenu.title')}</span>
                </h1>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 px-4">
                    {menuItems.map((item, index) => (
                        <button key={index} onClick={item.action}
                            className={`bg-white/70 backdrop-blur-md group relative rounded-[2rem] p-6 flex items-center gap-6
                                border border-slate-200/60 shadow-md hover:shadow-2xl hover:-translate-y-1 hover:border-blue-200 transition-all duration-300 active:scale-[0.98]
                                ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
                            style={{ transitionDelay: `${200 + index * 80}ms` }}>
                            <div className={`p-4 rounded-2xl bg-gradient-to-br ${item.color} text-white group-hover:scale-110 group-hover:shadow-lg transition-transform duration-300`}>{item.icon}</div>
                            <div className="text-left flex-1">
                                <h2 className="text-xl font-bold text-slate-800 group-hover:text-blue-600 transition-colors uppercase tracking-wide">{item.name}</h2>
                                <p className="text-slate-500 text-sm font-medium mt-1">{item.sub}</p>
                            </div>
                            <div className={`w-1.5 h-12 rounded-full bg-gradient-to-b ${item.color} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}></div>
                        </button>
                    ))}
                </div>
            </div>
            </div>

            {showCreateModal && (
                <div className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
                    <div className="bg-white/90 backdrop-blur-xl rounded-[2rem] p-8 w-full max-w-md relative animate-scale-in border border-white shadow-2xl">
                        <button onClick={() => setShowCreateModal(false)} className="absolute top-6 right-6 text-slate-400 hover:text-red-500 transition-colors bg-slate-100 hover:bg-red-50 p-2 rounded-full"><X size={20} /></button>
                        <h2 className="text-2xl font-black text-slate-800 mb-6 flex items-center gap-3"><PlusSquare size={24} className="text-emerald-500" /> {t('onlineMenu.createModal.title')}</h2>
                        <form onSubmit={handleCreateRoom} className="space-y-5">
                            <div>
                                <label className="text-blue-600 text-xs font-bold tracking-widest uppercase">{t('onlineMenu.createModal.roomName')}</label>
                                <input type="text" className="w-full bg-slate-50 border border-slate-200 text-slate-800 p-3 rounded-xl mt-1.5 focus:outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-100 transition-all font-medium"
                                    value={createData.roomName} onChange={(e) => setCreateData({ ...createData, roomName: e.target.value })} required />
                            </div>
                            <div>
                                <label className="text-blue-600 text-xs font-bold tracking-widest uppercase">{t('onlineMenu.createModal.maxPlayers')} ({createData.maxPlayers})</label>
                                <input type="range" min="2" max="5" className="w-full mt-3 accent-blue-600 cursor-pointer h-2 bg-slate-200 rounded-lg appearance-none"
                                    value={createData.maxPlayers} onChange={(e) => setCreateData({ ...createData, maxPlayers: parseInt(e.target.value) })} />
                                <div className="flex justify-between text-slate-400 font-bold text-xs mt-2 px-1"><span>2</span><span>3</span><span>4</span><span>5</span></div>
                            </div>
                            <div>
                                <label className="text-blue-600 text-xs font-bold tracking-widest uppercase">{t('onlineMenu.createModal.password')}</label>
                                <input type="text" placeholder={t('onlineMenu.createModal.passwordPlaceholder')}
                                    className="w-full bg-slate-50 border border-slate-200 text-slate-800 p-3 rounded-xl mt-1.5 focus:outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-100 transition-all placeholder-slate-400 font-medium"
                                    value={createData.password} onChange={(e) => setCreateData({ ...createData, password: e.target.value })} />
                            </div>
                            <button type="submit" className="w-full bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-bold py-4 rounded-xl transition-all duration-300 shadow-lg shadow-emerald-500/30 active:scale-[0.98] mt-4 tracking-wide uppercase">{t('onlineMenu.createModal.submit')}</button>
                        </form>
                    </div>
                </div>
            )}

            {showSettingsModal && (
                <div className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
                    <div className="bg-white/90 backdrop-blur-xl rounded-[2rem] p-8 w-full max-w-md relative animate-scale-in border border-white shadow-2xl">
                        <button onClick={() => setShowSettingsModal(false)} className="absolute top-6 right-6 text-slate-400 hover:text-red-500 transition-colors bg-slate-100 hover:bg-red-50 p-2 rounded-full"><X size={20} /></button>
                        <h2 className="text-2xl font-black text-slate-800 mb-8 flex items-center gap-3"><Settings size={24} className="text-blue-600" /> {t('onlineMenu.settingsModal.title')}</h2>
                        <div className="space-y-6">
                            <div>
                                <label className="text-amber-500 text-xs font-bold flex items-center gap-2 tracking-widest uppercase mb-3"><Volume2 size={16} /> {t('onlineMenu.settingsModal.musicVolume')}</label>
                                <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
                                    <input type="range" min="0" max="100" className="w-full accent-blue-600 cursor-pointer h-2 bg-slate-200 rounded-lg appearance-none" value={settingData.volume}
                                        onChange={(e) => { const vol = e.target.value; setSettingData({ ...settingData, volume: vol }); const m = document.getElementById('bg-music'); if (m) { m.volume = vol / 100; if (m.paused) m.play(); } localStorage.setItem('musicVolume', vol); }} />
                                    <div className="text-slate-700 font-bold text-sm min-w-[3rem] text-right">{settingData.volume}%</div>
                                </div>
                            </div>
                            <div>
                                <label className="text-blue-600 text-xs font-bold flex items-center gap-2 tracking-widest uppercase mb-3"><User size={16} /> {t('onlineMenu.settingsModal.displayName')}</label>
                                <input type="text" className="w-full bg-slate-50 border border-slate-200 text-slate-800 p-3 rounded-xl focus:outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-100 transition-all font-medium"
                                    value={settingData.newName} onChange={(e) => setSettingData({ ...settingData, newName: e.target.value })} />
                            </div>
                            <button onClick={handleSaveSettings} className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-4 rounded-xl transition-all duration-300 shadow-lg shadow-blue-500/30 active:scale-[0.98] flex items-center justify-center gap-2 mt-4 uppercase tracking-wide"><Save size={18} /> {t('onlineMenu.settingsModal.saveChanges')}</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}