import { useState, useEffect } from 'react';
import axios from 'axios';
import { Lock, User, Search, Frown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

export default function JoinRoom() {
    const [rooms, setRooms] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [mounted, setMounted] = useState(false);
    const navigate = useNavigate();
    const { t } = useTranslation();

    useEffect(() => { setTimeout(() => setMounted(true), 100); }, []);
    useEffect(() => {
        axios.get(`http://localhost:3001/rooms?search=${searchTerm}`).then(r => setRooms(r.data)).catch(() => {});
    }, [searchTerm]);

    return (
        <div className="min-h-screen relative overflow-hidden p-8 transition-colors duration-300 bg-slate-50">
            <div className="absolute inset-0 bg-white/40 pointer-events-none"></div>

            <div className="max-w-6xl mx-auto relative z-10">
                <div className={`flex flex-col md:flex-row justify-between items-center mb-10 gap-4 transition-all duration-700 ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'}`}>
                    <h1 className="text-4xl font-black tracking-tight"><span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">{t('joinRoom.title')}</span></h1>
                    <div className="relative w-full md:w-96 shadow-sm rounded-xl">
                        <Search className="absolute left-4 top-3.5 text-slate-400" size={18} />
                        <input type="text" placeholder={t('joinRoom.searchPlaceholder', "ค้นหาชื่อห้อง...")}
                            className="w-full bg-white border border-slate-200 rounded-xl py-3 pl-11 pr-4 text-slate-800 text-sm font-medium focus:border-blue-400 focus:ring-4 focus:ring-blue-100 focus:outline-none transition-all placeholder-slate-400"
                            onChange={(e) => setSearchTerm(e.target.value)} />
                    </div>
                </div>

                {rooms.length === 0 ? (
                    <div className={`flex flex-col items-center justify-center h-72 bg-white/70 backdrop-blur-md rounded-[2rem] border-2 border-dashed border-slate-200 transition-all duration-700 shadow-sm ${mounted ? 'opacity-100' : 'opacity-0'}`}>
                        <Frown size={56} className="text-slate-300 mb-6 animate-float" />
                        <h3 className="text-2xl text-slate-700 font-bold mb-2">{t('joinRoom.noRooms')}</h3>
                        <p className="text-slate-500 font-medium">{t('joinRoom.noRoomsSub')}</p>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {rooms.map((room, i) => (
                            <div key={room.room_id}
                                className={`bg-white/80 backdrop-blur-xl rounded-2xl p-6 group hover:border-blue-200 border border-slate-200 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 relative overflow-hidden
                                    ${mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
                                style={{ transitionDelay: `${150 + i * 50}ms` }}>
                                <div className="absolute -top-4 -right-4 p-4 opacity-[0.03] group-hover:opacity-[0.06] transition-opacity"><User size={96} className="text-blue-600" /></div>
                                <div className="flex justify-between items-start mb-4 relative z-10">
                                    <h3 className="text-xl font-bold text-slate-800 truncate pr-4 group-hover:text-blue-600 transition-colors uppercase tracking-wide">{room.room_name}</h3>
                                    {room.room_password && <Lock size={18} className="text-red-500 flex-shrink-0" />}
                                </div>
                                <div className="flex items-center text-slate-600 mb-6 relative z-10 bg-slate-100/80 px-4 py-2 rounded-xl w-fit text-sm border border-slate-200/60 font-medium">
                                    <User size={16} className="mr-2 text-slate-400" /><span className="font-bold">{room.current_players} / {room.max_players}</span>
                                </div>
                                <button onClick={() => navigate(`/lobby/${room.room_id}`)}
                                    className="w-full py-3.5 rounded-xl text-white font-bold text-sm relative z-10 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-md hover:shadow-lg hover:shadow-blue-500/30 transition-all duration-300 active:scale-[0.98] uppercase tracking-wider">
                                    {t('joinRoom.joinBtn')}
                                </button>
                            </div>
                        ))}
                    </div>
                )}

                <button onClick={() => navigate('/online')} className={`mt-10 inline-flex items-center text-slate-400 hover:text-blue-600 text-sm font-bold transition-colors duration-300 uppercase tracking-widest ${mounted ? 'opacity-100' : 'opacity-0'}`}>
                    ← {t('joinRoom.back')}
                </button>
            </div>
        </div>
    );
}