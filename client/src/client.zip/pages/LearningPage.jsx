//Learnแบบสวย
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronDown,
  Lock,
  PlayCircle,
  CheckCircle2,
  Trophy,
} from "lucide-react";
import { useEffect, useState } from "react";
import axios from "axios";
import { useTranslation } from "react-i18next";

// ######################################################################
// ### MAIN PAGE: LearningPage
// ######################################################################
export default function LearningPage({ onNavigate, user }) {
  const [modules, setModules] = useState([]);
  const [loading, setLoading] = useState(true);
  const { t } = useTranslation();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
  };

// ใน LearningPage.jsx
useEffect(() => {
  // 1. ถ้าไม่มี user ให้หยุดทำงานก่อน
  if (!user) return;

  const fetchData = async () => {
    try {
      setLoading(true);
      // 2. ดึงข้อมูลใหม่จาก API ทุกครั้งที่ user เปลี่ยนแปลง
      const res = await axios.get("http://localhost:3001/api/course-content", {
        params: { 
          user_id: user.user_id, 
          user_level: user.level // ✅ ส่งเลเวลปัจจุบันไปเช็ค
        }
      });
      setModules(res.data);
      console.log("🔄 ข้อมูลอัปเดตล่าสุดสำหรับเลเวล:", user.level);
    } catch (err) {
      console.error("❌ ดึงข้อมูลไม่สำเร็จ:", err);
    } finally {
      setLoading(false);
    }
  };

  fetchData();

// 💡 หัวใจสำคัญคือตรงนี้! ใส่ [user] เพื่อบอกว่า "ถ้า user เปลี่ยน (เช่น เลเวลอัป) ให้รันฟังก์ชันข้างบนใหม่ทันที"
}, [user]);

  if (loading) {
    return (
      <div className="flex flex-col justify-center items-center h-96 space-y-4">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        <p className="text-text-secondary animate-pulse">เตรียมบทเรียนให้คุณ {user?.username}...</p>
      </div>
    );
  }

  return (
    <div className="pb-20">
      <HeroSection />
      
      <main className="max-w-3xl mx-auto py-12 px-4">
        {/* มาสคอตทักทาย */}
        <MascotSpeechBubble username={user?.username} />

        {/* รายการ Module ต่างๆ */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-6"
        >
{modules.map((mod) => {
  // 1. แปลงค่าให้เป็นตัวเลขเสมอเพื่อป้องกันบั๊ก
  const reqLevel = Number(mod.required_level || 0); 
  const myLevel = Number(user?.level || 1);

  // 2. เช็คเงื่อนไข: ถ้าเลเวลเรา "น้อยกว่า" เกณฑ์ ให้ล็อค (isLocked = true)
  const isLocked = myLevel < reqLevel;

  // 3. พิมพ์เช็คใน Console ดูความจริง
  console.log(`${mod.title} -> ต้องใช้: ${reqLevel}, เลเวลหนู: ${myLevel}, ล็อคไหม: ${isLocked}`);

  return (
    <ModuleAccordion 
      key={mod.module_id} 
      moduleData={mod} 
      isLocked={isLocked} // ✅ ส่งค่าที่คำนวณได้ไปใช้งาน
      userLevel={myLevel}
    />
  );
})}
        </motion.div>

        {/* Achievement Section */}
        <div className="mt-28 text-center pt-16 relative">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-[1px] bg-gradient-to-r from-transparent via-slate-300 to-transparent"></div>
          <div className="inline-flex p-5 bg-white rounded-[2rem] shadow-xl border border-slate-100 mb-8 transform -translate-y-12">
             <Trophy className="w-12 h-12 text-amber-500" strokeWidth={1.5} />
          </div>
          <h2 className="text-3xl font-bold text-slate-800 tracking-tight">{t("footer.title") || "ก้าวต่อไปของคุณรออยู่"}</h2>
          <p className="mt-4 text-slate-500 max-w-md mx-auto leading-relaxed">
            {t("footer.subtitle") || "การเรียนรู้ไม่มีที่สิ้นสุด สะสมความสำเร็จและประสบการณ์ของคุณที่นี่"}
          </p>
        </div>
      </main>
    </div>
  );
}

// ######################################################################
// ### SUB-COMPONENT: ModuleAccordion
// ######################################################################
const ModuleAccordion = ({ moduleData, isFirst, isLocked, onNavigate, userLevel }) => {
  const [isOpen, setIsOpen] = useState(isFirst);
  const { title, lessons, required_level } = moduleData;

  // คำนวณ % ความสำเร็จของ Module
  const calculateProgress = () => {
    if (!lessons || lessons.length === 0) return 0;
    const completed = lessons.reduce((sum, l) => sum + (l.completed_count || 0), 0);
    const total = lessons.reduce((sum, l) => sum + (l.total_count || 0), 0);
    return total === 0 ? 0 : Math.round((completed / total) * 100);
  };

  const progress = calculateProgress();

  return (
    <motion.div
      variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }}
      className={`bg-white/80 backdrop-blur-xl rounded-[2rem] shadow-lg transition-all duration-350 overflow-hidden relative group
        ${isLocked 
          ? "border border-slate-200 opacity-60 grayscale-[0.4]" 
          : "border border-slate-200/60 hover:border-blue-200 hover:shadow-2xl hover:shadow-blue-500/10 hover:-translate-y-1"
        }`}
    >
      {/* Module Header */}
      <div
        className={`flex items-center p-6 ${isLocked ? "cursor-not-allowed" : "cursor-pointer"}`}
        onClick={() => !isLocked && setIsOpen(!isOpen)}
      >
        <div className="flex-shrink-0 mr-5 relative z-10">
          {isLocked ? (
            <div className="w-16 h-16 flex items-center justify-center bg-slate-100 rounded-[1.25rem] shadow-inner border border-slate-200">
              <Lock className="w-7 h-7 text-slate-400" strokeWidth={1.5} />
            </div>
          ) : (
            <CircularProgress progress={progress} />
          )}
        </div>

        <div className="flex-grow z-10">
          <div className="flex items-center space-x-3 mb-1.5">
            <h3 className="text-xl font-bold text-slate-800 tracking-tight">{title}</h3>
            {isLocked && (
              <span className="text-[10px] bg-red-50 text-red-600 px-2.5 py-1 rounded-full font-bold uppercase tracking-widest border border-red-100">
                Level {required_level}
              </span>
            )}
          </div>
          <p className="text-sm font-medium text-slate-500">
            {isLocked ? "เรียนรู้พื้นฐานเพิ่มเติมเพื่อปลดล็อก" : `${lessons?.length || 0} บทเรียนในหมวดนี้`}
          </p>
        </div>

        {!isLocked && (
          <motion.div animate={{ rotate: isOpen ? 180 : 0 }}>
            <ChevronDown className="w-5 h-5 text-text-secondary" />
          </motion.div>
        )}
      </div>

      {/* Lesson List */}
      <AnimatePresence>
        {isOpen && !isLocked && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-6 pb-6 pt-2 bg-slate-50/50 border-t border-slate-100/80">
              <ul className="space-y-2">
                {lessons.map((lesson) => {
                  // เช็ค Lock รายบทเรียน (ถ้ามี)
                  const isLessonLocked = userLevel < (lesson.required_level || 0);

                  return (
                    <li
                      key={lesson.lesson_id || lesson.id}
                      className={`group flex justify-between items-center p-4 rounded-2xl transition-all duration-300 border border-transparent
                        ${isLessonLocked 
                          ? "opacity-50 cursor-not-allowed bg-slate-50 border-slate-100" 
                          : "hover:bg-white hover:border-slate-200 hover:shadow-md cursor-pointer active:scale-[0.98]"
                        }`}
                      onClick={() => !isLessonLocked && onNavigate('lesson', lesson.lesson_id || lesson.id, moduleData)}
                    >
                      <div className="flex items-center space-x-4">
                        <div className={`p-2.5 rounded-xl transition-colors duration-300 shadow-sm ${isLessonLocked ? "bg-slate-200" : "bg-blue-50 group-hover:bg-blue-100 text-blue-600"}`}>
                          {isLessonLocked ? <Lock className="w-5 h-5 text-slate-500" strokeWidth={1.5} /> : <PlayCircle className="w-5 h-5" strokeWidth={1.5} />}
                        </div>
                        <span className="text-base font-bold text-slate-700">{lesson.title}</span>
                      </div>

                      <div className="flex items-center space-x-5">
                        <span className="text-[11px] font-mono font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200">
                          {lesson.completed_count || 0}/{lesson.total_count || 0}
                        </span>
                        {!isLessonLocked && (
                           <div className="w-8 h-8 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center group-hover:bg-blue-600 group-hover:border-blue-600 group-hover:text-white transition-all duration-300 group-hover:scale-110 shadow-sm">
                              <ChevronDown className="w-4 h-4 -rotate-90" />
                           </div>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// ######################################################################
// ### HELPER COMPONENTS
// ######################################################################

const HeroSection = () => {
    const { t } = useTranslation();
    return (
        <div className="relative h-[360px] w-full rounded-b-[3rem] overflow-hidden shadow-xl mb-12">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-indigo-600 to-violet-700"></div>
            
            {/* Elegant glass overlays */}
            <div className="absolute inset-0 bg-white/10 backdrop-blur-sm -skew-y-3 origin-top-left scale-110 translate-y-20"></div>
            <div className="absolute right-0 top-0 w-[500px] h-[500px] bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"></div>
            
            <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center items-center text-center">
                <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.7, ease: "easeOut" }}
                >
                    <div className="inline-flex items-center gap-2 mb-6 px-4 py-2 rounded-full border border-white/20 bg-white/10 backdrop-blur-md">
                      <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                      <span className="text-white/90 text-sm font-medium tracking-wide">ยินดีต้อนรับสู่โลกแห่งการเรียนรู้</span>
                    </div>
                </motion.div>
                
                <motion.h1
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
                    className="text-4xl md:text-6xl font-black text-white tracking-tight drop-shadow-lg"
                >
                    {t('hero.title') || "Start Your Journey"}
                </motion.h1>
                <motion.p
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 0.3 }}
                    className="mt-6 text-lg md:text-xl text-indigo-100 max-w-2xl font-light leading-relaxed"
                >
                    {t('hero.subtitle') || "เรียนรู้ไปพร้อมกับความสนุก พัฒนาทักษะของคุณในบรรยากาศพรีเมียม"}
                </motion.p>
            </div>
        </div>
    );
};


const CircularProgress = ({ progress }) => {
  const radius = 24;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <div className="relative w-16 h-16 flex items-center justify-center bg-white rounded-[1.25rem] shadow-sm border border-slate-100">
      <svg className="w-14 h-14 rotate-[-90deg]">
        <circle className="text-slate-100" stroke="currentColor" strokeWidth="4" fill="transparent" r={radius} cx="28" cy="28" />
        <motion.circle
          stroke="#3b82f6"
          strokeWidth="4"
          strokeLinecap="round"
          fill="transparent"
          r={radius}
          cx="28"
          cy="28"
          style={{ strokeDasharray: circumference, strokeDashoffset: offset }}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1.5, ease: "easeOut" }}
        />
      </svg>
      <span className="absolute text-[11px] font-black text-slate-700">{progress}%</span>
    </div>
  );
};

const MascotSpeechBubble = ({ username }) => {
  const { t } = useTranslation();
  return (
<motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 200, damping: 20 }}
      className="bg-white/80 backdrop-blur-xl border border-slate-200 rounded-[2.5rem] p-6 pr-8 mb-12 shadow-xl shadow-slate-200/50 flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-6 relative text-center md:text-left overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-64 h-64 bg-amber-100/30 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"></div>
      <div className="relative flex-shrink-0">
        <div className="w-20 h-20 bg-slate-100 rounded-[1.5rem] flex items-center justify-center border-2 border-white shadow-lg overflow-hidden relative">
            <img src="/cat-mascot.png" alt="Mascot" className="h-16 w-16 drop-shadow-md z-10 relative object-contain" />
            <div className="absolute inset-0 bg-blue-100/50"></div>
        </div>
        <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 border-4 border-white rounded-full shadow-sm"></div>
      </div>
      <div className="relative z-10 pt-1">
        <h4 className="font-bold text-slate-800 text-lg tracking-tight">โค้ดดี้ แมวเหลือง</h4>
        <p className="text-slate-500 text-sm leading-relaxed mt-1 font-medium">
          {t('mascot.welcome') || "ยินดีต้อนรับกลับมานะ"}, <span className="font-bold text-blue-600 px-1">{username || 'นักเรียน'}</span>! 
          <br/>บทเรียนทั้งหมดพร้อมให้คุณสนุกแล้ว มาเริ่มผจญภัยในโลกโค้ดกันเถอะ!
        </p>
      </div>
    </motion.div>
  );
  
};