import React, { useState } from "react";
import { motion } from "framer-motion";
import { Palette, MousePointer2, Zap, Store } from "lucide-react";
import { useTranslation } from "react-i18next"; // <-- 1. Import

// --- Mock Data (อัปเดต: ลบ name ออก) ---
const shopItems = [
    { id: 'theme-default', type: 'theme', price: 0, previewImage: '/images/theme-default.png' },
    { id: 'theme-sakura', type: 'theme', price: 0, previewImage: '/images/theme-sakura.png' },
    { id: 'theme-ocean', type: 'theme', price: 0, previewImage: '/images/theme-ocean.png' },
    { id: 'cursor-sparkle', type: 'cursor', price: 0, previewImage: '/images/cursor-sparkle.png' },
    { id: 'cursor-ghost', type: 'cursor', price: 0, previewImage: '/images/cursor-ghost.png' },
    { id: 'click-ripple', type: 'click', price: 0, previewImage: '/images/click-ripple.png' },
    { id: 'click-burst', type: 'click', price: 0, previewImage: '/images/click-burst.png' },
];

// --- 1. Shop Page (Main Component) ---
export default function ShopPage({ onTry }) {
    const [filters, setFilters] = useState({
        theme: true,
        cursor: true,
        click: true,
    });

    const filteredItems = shopItems.filter(item => {
        if (item.type === 'theme') return filters.theme;
        if (item.type === 'cursor') return filters.cursor;
        if (item.type === 'click') return filters.click;
        return true;
    });

    return (
        <main className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8 relative z-10">
            {/* Elegant Header */}
            <div className="text-center mb-12 relative">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-white rounded-[1.5rem] shadow-xl border border-slate-100 mb-6 relative">
                 <Store className="w-10 h-10 text-blue-600" />
                 <div className="absolute -top-2 -right-2 w-6 h-6 bg-amber-400 rounded-full border-4 border-slate-50 animate-bounce"></div>
              </div>
              <h1 className="text-4xl md:text-5xl font-black text-slate-800 tracking-tight">ร้านค้าไอเทม</h1>
              <p className="mt-4 text-slate-500 text-lg max-w-2xl mx-auto">ปรับแต่งประสบการณ์การเรียนรู้ในแบบฉบับของคุณ</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">

                {/* --- Sidebar (ซ้าย) --- */}
                <FilterSidebar filters={filters} setFilters={setFilters} />

                {/* --- Grid (ขวา) --- */}
                <div className="lg:col-span-3">
                    <motion.div
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                        variants={{
                            hidden: { opacity: 0 },
                            visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
                        }}
                        initial="hidden"
                        animate="visible"
                    >
                        {filteredItems.map(item => (
                            <ShopItemCard key={item.id} item={item} onTry={onTry} />
                        ))}
                    </motion.div>
                </div>

            </div>
        </main>
    );
};

// --- 2. Components ย่อยของ ShopPage ---
const FilterSidebar = ({ filters, setFilters }) => {
    const { t } = useTranslation(); // <-- 2. เรียกใช้ t()

    const toggleFilter = (key) => {
        setFilters(prev => ({ ...prev, [key]: !prev[key] }));
    };

    const FilterButton = ({ labelKey, type }) => (
        <button
            onClick={() => toggleFilter(type)}
            className={`w-full text-left px-5 py-3.5 rounded-2xl font-bold transition-all duration-300 border flex items-center justify-between ${filters[type]
                    ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/20'
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
        >
            <span>{t(labelKey)}</span>
            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${filters[type] ? 'border-white bg-white/20' : 'border-slate-300'}`}>
                {filters[type] && <div className="w-2.5 h-2.5 rounded-full bg-white"></div>}
            </div>
        </button>
    );

    return (
        <aside className="p-6 bg-white/80 backdrop-blur-xl rounded-[2rem] shadow-xl border border-slate-200/60 h-fit sticky top-24">
            <h3 className="text-xl font-bold text-slate-800 mb-6 bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">{t('shop.sidebar.title') || "หมวดหมู่"}</h3>
            <div className="space-y-3">
                <FilterButton labelKey="shop.sidebar.themes" type="theme" />
                <FilterButton labelKey="shop.sidebar.cursors" type="cursor" />
                <FilterButton labelKey="shop.sidebar.clicks" type="click" />
            </div>
            
            <div className="mt-8 p-5 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl border border-amber-100 flex items-start space-x-3">
              <Zap className="w-5 h-5 text-amber-500 mt-0.5 flex-shrink-0" />
              <p className="text-sm font-medium text-amber-800">ไอเทมฟรีทั้งหมด! ทดลองใช้ได้เลย ไม่ต้องใช้เหรียญ</p>
            </div>
        </aside>
    );
};

const ShopItemCard = ({ item, onTry }) => {
    const { t } = useTranslation(); // <-- 2. เรียกใช้ t()
    const { id, price, previewImage, type } = item; // <-- เอา name ออก

    const Icon = type === 'theme' ? Palette : type === 'cursor' ? MousePointer2 : Zap;

    // 3. ใช้ t() แปลชื่อ Item โดยใช้ ID เป็น Key
    const name = t(`shop.items.${id}`);

    return (
        <motion.div
            variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 }
            }}
            className="bg-white/90 backdrop-blur-md rounded-[1.5rem] shadow-lg border border-slate-200/60 overflow-hidden flex flex-col group hover:-translate-y-1 hover:shadow-xl transition-all duration-300"
        >
            <div className="relative w-full h-48 bg-slate-100 overflow-hidden border-b border-slate-100">
                <img src={previewImage} alt={name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-full shadow-sm flex items-center space-x-2 border border-slate-200/50">
                    <Icon className="w-4 h-4 text-blue-600" />
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">{type}</span>
                </div>
            </div>
            
            <div className="p-6 flex flex-col flex-grow bg-white">
                <h4 className="text-lg font-bold text-slate-800 truncate">{name}</h4>
                <div className="flex items-center text-amber-500 mt-2">
                    <span className="font-extrabold text-sm uppercase tracking-wider bg-amber-50 px-3 py-1 rounded-lg border border-amber-100/50">
                        {price === 0 ? t('shop.card.free') || 'FREE' : price}
                    </span>
                </div>
                
                <button
                    onClick={() => onTry(item)}
                    className="w-full mt-6 bg-slate-900 text-white font-bold py-3 px-4 rounded-xl hover:bg-blue-600 shadow-md hover:shadow-blue-500/30 transition-all duration-300 active:scale-[0.98]"
                >
                    {t('shop.card.try') || 'ทดลองใช้'}
                </button>
            </div>
        </motion.div>
    );
};